"""namespace of internal API"""
