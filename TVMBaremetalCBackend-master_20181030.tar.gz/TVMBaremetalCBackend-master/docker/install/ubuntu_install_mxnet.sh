pip3 install mxnet
