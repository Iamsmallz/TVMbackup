apt-get update --fix-missing

apt-get install -y --no-install-recommends --force-yes \
        libgl1-mesa-dev libglfw3-dev