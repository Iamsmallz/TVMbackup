"""Module space to register contrib functions. Leave empty"""
