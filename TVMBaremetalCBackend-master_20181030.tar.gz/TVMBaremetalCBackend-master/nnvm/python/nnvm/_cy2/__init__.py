"""Namespace for cython generated modules for python2"""
