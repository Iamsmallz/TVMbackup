Example Extension Library
=========================
This folder contains an example extension library of TVM.
It demonstrates how can other library extend TVM in both C++ and python API.

- The library extends TVM's functionality.
- The python module load the new shared library and can interpolate with TVM's python API.
