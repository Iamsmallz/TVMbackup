VTA Hardware Design Overview
============================
