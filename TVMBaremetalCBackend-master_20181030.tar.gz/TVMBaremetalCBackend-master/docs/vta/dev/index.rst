VTA Design and Developer Guide
==============================

This developer guide details the complete VTA-TVM hardware-software stack.

.. image:: http://raw.githubusercontent.com/uwsaml/web-data/master/vta/blogpost/vta_stack.png
   :align: center
   :width: 60%

.. toctree::
   :maxdepth: 2

   config
   hardware