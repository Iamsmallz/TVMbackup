tvm.rpc
-------
.. automodule:: tvm.rpc

.. autofunction:: tvm.rpc.connect
.. autofunction:: tvm.rpc.connect_tracker

.. autoclass:: tvm.rpc.TrackerSession
    :members:
    :inherited-members:

.. autoclass:: tvm.rpc.RPCSession
    :members:
    :inherited-members:

.. autoclass:: tvm.rpc.LocalSession
    :members:
    :inherited-members:

.. autoclass:: tvm.rpc.Server
    :members:
    :inherited-members:
