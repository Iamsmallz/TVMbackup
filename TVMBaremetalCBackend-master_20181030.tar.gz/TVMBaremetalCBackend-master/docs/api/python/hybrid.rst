tvm.hybrid
----------
.. automodule:: tvm.hybrid

.. autosummary::

   tvm.hybrid.parse
   tvm.hybrid.script

.. autofunction:: tvm.hybrid.parse
.. autofunction:: tvm.hybrid.script
