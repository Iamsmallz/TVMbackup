tvm.intrin
----------
.. automodule:: tvm.intrin

.. autosummary::

   tvm.call_packed
   tvm.call_pure_intrin
   tvm.call_pure_extern
   tvm.register_intrin_rule
   tvm.exp
   tvm.log
   tvm.floor
   tvm.ceil
   tvm.trunc
   tvm.round
   tvm.abs

.. autofunction:: tvm.call_packed
.. autofunction:: tvm.call_pure_intrin
.. autofunction:: tvm.call_pure_extern
.. autofunction:: tvm.register_intrin_rule
.. autofunction:: tvm.exp
.. autofunction:: tvm.log
.. autofunction:: tvm.floor
.. autofunction:: tvm.ceil
.. autofunction:: tvm.trunc
.. autofunction:: tvm.round
.. autofunction:: tvm.abs
