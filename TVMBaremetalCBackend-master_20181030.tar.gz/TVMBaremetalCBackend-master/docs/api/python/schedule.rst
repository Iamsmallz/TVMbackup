tvm.schedule
------------
.. automodule:: tvm.schedule

.. autoclass:: tvm.schedule.IterVar
    :members:

.. autoclass:: tvm.schedule.Buffer
    :members:

.. autofunction:: tvm.create_schedule

.. autoclass:: tvm.schedule.Schedule
    :members:
    :inherited-members:

.. autoclass:: tvm.schedule.Stage
    :members:
    :inherited-members:
